
This project helps users find the best route between cities.

DSA Concepts Used:
1. Graph
2. Greedy Algorithm - Dijkstra Algorithm
3. Dynamic Programming

Language Used: C++
IDE Used: Visual Studio Code