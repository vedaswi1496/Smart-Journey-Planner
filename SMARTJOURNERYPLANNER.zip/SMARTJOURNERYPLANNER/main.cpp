#include <iostream>
#include <vector>
#include <limits.h>
using namespace std;

int n;
int graph[10][10];
int cost[10][10];

void addRoute() {
    int u,v,d,c;
    cout<<"Enter source city number: ";
    cin>>u;
    cout<<"Enter destination city number: ";
    cin>>v;
    cout<<"Enter distance: ";
    cin>>d;
    cout<<"Enter cost: ";
    cin>>c;

    graph[u][v] = d;
    cost[u][v] = c;
}

void showRoutes() {
    cout<<"Distance Matrix\n";

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<graph[i][j]<<" ";
        }
        cout<<endl;
    }
}

void shortestPath(int src){

    int dist[10];
    bool visited[10];

    for(int i=0;i<n;i++){
        dist[i] = INT_MAX;
        visited[i] = false;
    }

    dist[src] = 0;

    for(int count=0;count<n-1;count++){

        int min = INT_MAX, u;

        for(int i=0;i<n;i++)
            if(!visited[i] && dist[i] <= min){
                min = dist[i];
                u = i;
            }

        visited[u] = true;

        for(int v=0;v<n;v++)
            if(!visited[v] && graph[u][v] &&
               dist[u] != INT_MAX &&
               dist[u] + graph[u][v] < dist[v])

                dist[v] = dist[u] + graph[u][v];
    }

    cout<<"Shortest Distances:\n";

    for(int i=0;i<n;i++)
        cout<<"City "<<i<<" : "<<dist[i]<<endl;
}

void minimumCostDP(int src){

    int dp[10];

    for(int i=0;i<n;i++)
        dp[i] = INT_MAX;

    dp[src] = 0;

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(cost[i][j] && dp[i] + cost[i][j] < dp[j]){
                dp[j] = dp[i] + cost[i][j];
            }
        }
    }

    cout<<"Minimum Cost to cities:\n";

    for(int i=0;i<n;i++)
        cout<<"City "<<i<<" : "<<dp[i]<<endl;
}

int main(){

    cout<<"Enter number of cities: ";
    cin>>n;

    int choice;

    while(true){

        cout<<"\n1.Add Route\n2.Show Routes\n3.Shortest Distance\n4.Minimum Cost\n5.Exit\n";

        cin>>choice;

        if(choice==1)
            addRoute();

        else if(choice==2)
            showRoutes();

        else if(choice==3){

            int src;
            cout<<"Enter source city: ";
            cin>>src;

            shortestPath(src);
        }

        else if(choice==4){

            int src;
            cout<<"Enter source city: ";
            cin>>src;

            minimumCostDP(src);
        }

        else
            break;
    }
}